/*
 * Created on Jan 21, 2018
 */
package mum.asd.iterator;


public interface Aggregation {

    public Iterator getIterator();
}
