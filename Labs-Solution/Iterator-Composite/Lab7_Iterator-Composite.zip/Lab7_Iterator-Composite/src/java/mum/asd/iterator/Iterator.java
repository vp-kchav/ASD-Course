/*
 * Created on Jan 21, 2018
 */
package mum.asd.iterator;


public interface Iterator {
    
    public Object getNext();
    public boolean hasNext();
    public void remove();

}
