package mum.asd.lab3_2;

public interface IRow {
	public String get();
	public void update(IRow row);
}
