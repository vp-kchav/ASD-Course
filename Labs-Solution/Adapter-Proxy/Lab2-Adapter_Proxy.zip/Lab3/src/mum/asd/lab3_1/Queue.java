package mum.asd.lab3_1;

/**
 * 
 * @author kimte
 *
 */
public interface Queue {
	public void queue(String str);
	public String dequeue();
	public boolean isEmpty();
}
