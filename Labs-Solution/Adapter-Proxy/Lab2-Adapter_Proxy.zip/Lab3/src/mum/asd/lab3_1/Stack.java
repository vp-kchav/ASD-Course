package mum.asd.lab3_1;

public interface Stack {
	public void push(String str);
	public String pop();
	public boolean isEmpty();
}
