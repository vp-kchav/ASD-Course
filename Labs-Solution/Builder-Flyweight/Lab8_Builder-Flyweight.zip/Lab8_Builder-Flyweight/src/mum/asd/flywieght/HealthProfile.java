package mum.asd.flywieght;

public class HealthProfile {

}

