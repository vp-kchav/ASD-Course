package mum.asd.flywieght;

public interface CustomerLogger {

	public void logCustomerInfo(String cutomerId,String firstName,String lastName);
}
