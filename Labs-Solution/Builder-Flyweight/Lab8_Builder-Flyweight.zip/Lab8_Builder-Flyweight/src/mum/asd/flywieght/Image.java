package mum.asd.flywieght;

public class Image {

	private City city;
	
	public Image(City city){
		//load map based on city
		this.city = city;
	}
	
}
