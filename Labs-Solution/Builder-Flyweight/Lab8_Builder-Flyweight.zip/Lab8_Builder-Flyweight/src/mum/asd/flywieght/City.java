package mum.asd.flywieght;

public enum City {
Fairfield,
Ottumwa,
MountPlesant,
Grinnel,
CedarRapid
}
