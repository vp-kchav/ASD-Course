package mum.asd.visitor;

public enum Side {
	RIGHT,LEFT,NONE;
}
