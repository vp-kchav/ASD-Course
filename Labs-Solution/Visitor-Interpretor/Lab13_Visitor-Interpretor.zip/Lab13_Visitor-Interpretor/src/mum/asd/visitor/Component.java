package mum.asd.visitor;

public interface Component {

	public void accept(NodeVisitor nodeVisitor);
}
