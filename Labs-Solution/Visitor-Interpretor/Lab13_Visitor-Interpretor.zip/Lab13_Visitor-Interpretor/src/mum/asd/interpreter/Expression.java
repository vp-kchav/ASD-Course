package mum.asd.interpreter;

public abstract class Expression {
	public abstract int Interpret();

}
