/*
 * Created on Jan 18, 2018
 */
package mum.asd.abstractfactory.packaging;


public class EverydayValue implements Packaging{

    @Override
    public float getCost() {
        return 0;
    }

    
}
