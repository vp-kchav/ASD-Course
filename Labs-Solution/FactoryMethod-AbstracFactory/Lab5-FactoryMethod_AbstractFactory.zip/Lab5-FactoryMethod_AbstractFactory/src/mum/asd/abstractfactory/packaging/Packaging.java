/*
 * Created on Jan 18, 2018
 */
package mum.asd.abstractfactory.packaging;


public interface Packaging {
    public float getCost();
}
