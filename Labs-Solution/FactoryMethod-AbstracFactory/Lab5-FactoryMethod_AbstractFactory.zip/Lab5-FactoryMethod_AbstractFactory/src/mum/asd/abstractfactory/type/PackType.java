/*
 * Created on Jan 18, 2018
 */
package mum.asd.abstractfactory.type;


public enum PackType {
    Business, Adults, Kids;
}
