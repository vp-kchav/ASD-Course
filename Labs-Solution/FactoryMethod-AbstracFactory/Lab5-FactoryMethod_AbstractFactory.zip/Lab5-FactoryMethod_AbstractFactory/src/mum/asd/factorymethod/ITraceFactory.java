package mum.asd.factorymethod;

public interface ITraceFactory {

	Trace getTrace(String type);
}
