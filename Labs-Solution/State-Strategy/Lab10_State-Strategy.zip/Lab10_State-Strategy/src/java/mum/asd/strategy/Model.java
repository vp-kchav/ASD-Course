/*
 * Created on Jan 23, 2018
 */
package mum.asd.strategy;

import java.util.List;

public interface Model {

    public int getRevenue(List<Flight> flights);
}
