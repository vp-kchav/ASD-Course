/*
 * Created on Jan 23, 2018
 */
package mum.asd.state;


public interface State {
    public void left();
    public void accel();
    public void right();
    public void brake();
}
