package mum.asd.mediator;

public interface Mediator {

	public void move(Player player,int x, int y);
	public void print();
}
