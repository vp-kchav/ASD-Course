package mum.asd.mediator;

public interface IPlayer {

    public void move(int x, int y);
}
