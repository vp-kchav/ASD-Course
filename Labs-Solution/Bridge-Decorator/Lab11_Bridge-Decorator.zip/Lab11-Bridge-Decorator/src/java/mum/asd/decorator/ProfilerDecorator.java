package mum.asd.decorator;


public class ProfilerDecorator extends ListDecorator {

	public ProfilerDecorator(Profiler decoratedList) {
		super(decoratedList);
	}

}
